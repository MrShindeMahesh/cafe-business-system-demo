import React, { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate } from 'react-router-dom';
import { Coffee, LayoutDashboard, UtensilsCrossed, Grid, Settings as SettingsIcon, LogOut, PieChart, Users, ShoppingCart, Package, Menu, X, ChefHat, ClipboardPlus, History, UserCog, Clock, Wallet, QrCode, ShoppingBag, CalendarDays } from 'lucide-react';
import { useData } from '../../context/DataContext';
import { useAuth } from '../../context/AuthContext';
import { canAccess } from '../../lib/roles';
import AttendanceModal from '../../components/admin/AttendanceModal';
import './Admin.css';

// Maps nav/route keys to sidebar items.
const NAV = [
  { key: 'index', path: '/admin', icon: <LayoutDashboard size={18} />, label: 'Live Orders', end: true },
  { key: 'take-order', path: '/admin/take-order', icon: <ClipboardPlus size={18} />, label: 'Take Order' },
  { key: 'kitchen', path: '/admin/kitchen', icon: <ChefHat size={18} />, label: 'Kitchen Display' },
  { key: 'todays-orders', path: '/admin/todays-orders', icon: <ShoppingCart size={18} />, label: "Today's Orders" },
  { key: 'history', path: '/admin/history', icon: <History size={18} />, label: 'Order History' },
  { key: 'tables', path: '/admin/tables', icon: <Grid size={18} />, label: 'Tables' },
  { key: 'parcel', path: '/admin/parcel', icon: <ShoppingBag size={18} />, label: 'Parcel' },
  { key: 'bookings', path: '/admin/bookings', icon: <CalendarDays size={18} />, label: 'Bookings' },
  { key: 'menu', path: '/admin/menu', icon: <UtensilsCrossed size={18} />, label: 'Menu' },
  { key: 'inventory', path: '/admin/inventory', icon: <Package size={18} />, label: 'Inventory' },
  { key: 'customers', path: '/admin/customers', icon: <Users size={18} />, label: 'Customers' },
  { key: 'analytics', path: '/admin/analytics', icon: <PieChart size={18} />, label: 'Analytics' },
  { key: 'expenses', path: '/admin/expenses', icon: <Wallet size={18} />, label: 'Expenses' },
  { key: 'upi-qr', path: '/admin/upi-qr', icon: <QrCode size={18} />, label: 'Show QR' },
  { key: 'staff', path: '/admin/staff', icon: <UserCog size={18} />, label: 'Staff' },
  { key: 'settings', path: '/admin/settings', icon: <SettingsIcon size={18} />, label: 'Settings' },
];

const ROLE_SUBTITLES = { admin: 'Owner', reception: 'Front Desk', waiter: 'Floor Staff', kitchen: 'Kitchen' };

export default function AdminLayout() {
  const navigate = useNavigate();
  const { settings } = useData();
  const { role, logout } = useAuth();
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const [showAttendance, setShowAttendance] = useState(false);
  // Waiter (and Reception) must mark attendance when they sign in.
  const needsAttendance = role === 'waiter' || role === 'reception';
  const navItems = NAV.filter((item) => canAccess(role, item.key));

  // Manual check-in only — no auto prompt on login.
  // Waiter/Reception go straight to their dashboard; they check in via the Attendance button below.

  const handleLogout = () => {
    logout();
    navigate('/login', { replace: true });
  };

  const initials = (role || '').slice(0, 2).toUpperCase();

  return (
    <div className="admin-layout animate-fade-in">
      {/* Mobile Backdrop */}
      {isMobileOpen && <div className="admin-sidebar-overlay" onClick={() => setIsMobileOpen(false)} />}

      <aside className={`admin-sidebar ${isMobileOpen ? 'mobile-open' : ''}`}>
                <div className="sidebar-logo">
          {settings?.cafeLogo ? (
            <img src={settings.cafeLogo} alt={settings?.cafeName || 'Café'} className="sidebar-logo-img" />
          ) : (
            <div className="sidebar-logo-icon"><Coffee size={22} /></div>
          )}
          <span className="sidebar-logo-text">{settings?.cafeName || 'La Casa'}</span>
          <button className="mobile-close-btn" onClick={() => setIsMobileOpen(false)}>
            <X size={20} />
          </button>
        </div>
        <p className="sidebar-section-label">Menu</p>
        <nav className="sidebar-nav">
          {navItems.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.end}
              onClick={() => setIsMobileOpen(false)}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''}`}
            >
              {item.icon}
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="sidebar-footer">
          <button className="sidebar-exit-btn" onClick={handleLogout}>
            <LogOut size={18} /> Logout
          </button>
        </div>
      </aside>

      <div className="admin-content">
        <header className="admin-header">
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <button className="mobile-menu-btn" onClick={() => setIsMobileOpen(true)}>
              <Menu size={22} />
            </button>
            {settings?.cafeLogo && (
              <img src={settings.cafeLogo} alt="logo" style={{ width: 32, height: 32, objectFit: 'contain', borderRadius: 6 }} />
            )}
            <span className="admin-header-title">{settings?.cafeName || 'La Casa'} Dashboard</span>
          </div>

          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem' }}>
            <div className="demo-badge">
              <span className="demo-dot animate-pulse"></span>
              Local Mode
            </div>
            {needsAttendance && (
              <button className="btn btn-outline btn-sm" style={{ whiteSpace: 'nowrap' }} onClick={() => setShowAttendance(true)}>
                <Clock size={14} /> Attendance
              </button>
            )}
            <div style={{ display: 'flex', alignItems: 'center', gap: '.75rem', borderLeft: '1px solid var(--color-border)', paddingLeft: '1rem' }}>
              <div style={{ textAlign: 'right', display: window.innerWidth < 640 ? 'none' : 'block' }}>
                <div style={{ fontSize: '.875rem', fontWeight: 600, color: 'var(--color-primary)' }}>
                  {role ? role.charAt(0).toUpperCase() + role.slice(1) : 'Staff'}
                </div>
                <div style={{ fontSize: '.75rem', color: 'var(--color-text-muted)' }}>{ROLE_SUBTITLES[role] || ''}</div>
              </div>
              <div className="admin-avatar">{initials || 'BB'}</div>
            </div>
          </div>
        </header>

        <main className="admin-main">
          <Outlet />
        </main>
      </div>

      {showAttendance && <AttendanceModal onClose={() => setShowAttendance(false)} />}
    </div>
  );
}
